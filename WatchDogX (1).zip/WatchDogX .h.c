#ifndef WATCHDOGX_H
#define WATCHDOGX_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <windows.h>

// Constants
#define ENCRYPTION_KEY 0xAB
#define LOG_FILE "logs.dat"

// Data structure for log entries
typedef struct Log {
    char message[128];
    char timestamp[32];
    struct Log* next;
} Log;

// Linked List & Log Management
void displayLogs();
void addLog();
void clearLogs();
void saveLogsToFile();
void loadLogsFromFile();
void addLogFromSerial(const char* message);

// Utility Functions
void xorEncryptDecrypt(unsigned char* data, size_t len);
void getTimestamp(char* buffer, int size);
void showWelcome();

// Serial Communication
char* detectArduinoPort(); // Optional (can use fixed COM)
HANDLE openSerialPort(const char* portName);
int readLineFromSerial(HANDLE hSerial, char* buffer, int maxLen);
void liveLogFeedFromArduino();
void rebootArduino(const char* portName);

#endif
