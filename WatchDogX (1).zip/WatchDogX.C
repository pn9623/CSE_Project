#include "WatchDogX.h"
#include <setupapi.h>
#include <initguid.h>
#include <devguid.h>
#include <conio.h>

Log* head = NULL;

void xorEncryptDecrypt(unsigned char* data, size_t len) {
    for (size_t i = 0; i < len; i++)
        data[i] ^= ENCRYPTION_KEY;
}

void getTimestamp(char* buffer, int size) {
    time_t now = time(NULL);
    struct tm* t = localtime(&now);
    strftime(buffer, size, "%Y-%m-%d %H:%M:%S", t);
}

void pauseScreen() {
    printf("\nPress Enter to return to menu...");
    getchar();
}

void clearLogs() {
    Log* temp = head;
    while (temp) {
        Log* next = temp->next;
        free(temp);
        temp = next;
    }
    head = NULL;
    printf("Logs cleared from memory.\n");
    Sleep(1000);
}

void displayLogs() {
    if (!head) {
        printf("No logs to display.\n");
        pauseScreen();
        return;
    }
    int count = 1;
    for (Log* temp = head; temp; temp = temp->next)
        printf("%d. [%s] %s\n", count++, temp->timestamp, temp->message);
    pauseScreen();
}

void saveLogsToFile() {
    FILE* file = fopen(LOG_FILE, "wb");
    if (!file) {
        printf("Error saving logs.\n");
        return;
    }
    for (Log* temp = head; temp; temp = temp->next) {
        Log encrypted = *temp;
        xorEncryptDecrypt((unsigned char*)encrypted.message, strlen(encrypted.message));
        xorEncryptDecrypt((unsigned char*)encrypted.timestamp, strlen(encrypted.timestamp));
        fwrite(&encrypted, sizeof(Log), 1, file);
    }
    fclose(file);
    printf("Logs saved to file.\n");
    Sleep(1000);
}

void loadLogsFromFile() {
    clearLogs();
    FILE* file = fopen(LOG_FILE, "rb");
    if (!file) {
        printf("No saved logs found.\n");
        return;
    }
    Log temp;
    while (fread(&temp, sizeof(Log), 1, file) == 1) {
        xorEncryptDecrypt((unsigned char*)temp.message, strlen(temp.message));
        xorEncryptDecrypt((unsigned char*)temp.timestamp, strlen(temp.timestamp));
        Log* newLog = malloc(sizeof(Log));
        if (!newLog) break;
        *newLog = temp;
        newLog->next = NULL;
        if (!head) head = newLog;
        else {
            Log* curr = head;
            while (curr->next) curr = curr->next;
            curr->next = newLog;
        }
    }
    fclose(file);
    printf("Logs loaded.\n");
    Sleep(1000);
}

void addLog() {
    int type;
    char tag[10], msg[100];
    printf("Select Log Type:\n1. INFO\n2. WARNING\n3. ALERT\nChoice: ");
    scanf("%d", &type); getchar();
    switch (type) {
        case 1: strcpy(tag, "[INFO]"); break;
        case 2: strcpy(tag, "[WARNING]"); break;
        case 3: strcpy(tag, "[ALERT]"); break;
        default: strcpy(tag, "[LOG]"); break;
    }
    printf("Enter log message: ");
    fgets(msg, sizeof(msg), stdin);
    msg[strcspn(msg, "\n")] = '\0';

    Log* newLog = malloc(sizeof(Log));
    snprintf(newLog->message, sizeof(newLog->message), "%s %s", tag, msg);
    getTimestamp(newLog->timestamp, sizeof(newLog->timestamp));
    newLog->next = NULL;

    if (!head) head = newLog;
    else {
        Log* temp = head;
        while (temp->next) temp = temp->next;
        temp->next = newLog;
    }
    saveLogsToFile();
    printf("Log added.\n");
    Sleep(1000);
}

void addLogFromSerial(const char* message) {
    Log* newLog = malloc(sizeof(Log));
    snprintf(newLog->message, sizeof(newLog->message), "[ARDUINO] %s", message);
    getTimestamp(newLog->timestamp, sizeof(newLog->timestamp));
    newLog->next = NULL;

    if (!head) head = newLog;
    else {
        Log* temp = head;
        while (temp->next) temp = temp->next;
        temp->next = newLog;
    }
    saveLogsToFile();
}

HANDLE openSerialPort(const char* portName) {
    HANDLE hSerial = CreateFileA(portName, GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);
    if (hSerial == INVALID_HANDLE_VALUE) return INVALID_HANDLE_VALUE;

    DCB dcb = {0};
    dcb.DCBlength = sizeof(dcb);
    GetCommState(hSerial, &dcb);
    dcb.BaudRate = CBR_9600;
    dcb.ByteSize = 8;
    dcb.Parity = NOPARITY;
    dcb.StopBits = ONESTOPBIT;
    SetCommState(hSerial, &dcb);

    COMMTIMEOUTS timeouts = {0};
    timeouts.ReadIntervalTimeout = 50;
    timeouts.ReadTotalTimeoutConstant = 50;
    timeouts.ReadTotalTimeoutMultiplier = 10;
    SetCommTimeouts(hSerial, &timeouts);

    return hSerial;
}

int readLineFromSerial(HANDLE hSerial, char* buffer, int maxLen) {
    char c;
    DWORD bytesRead;
    int i = 0;
    while (i < maxLen - 1) {
        if (!ReadFile(hSerial, &c, 1, &bytesRead, NULL)) return -1;
        if (bytesRead == 0) continue;
        if (c == '\n') break;
        buffer[i++] = c;
    }
    buffer[i] = '\0';
    return i;
}

void liveLogFeedFromArduino() {
    char* port = "\\\\.\\COM3";
    HANDLE serial = openSerialPort(port);
    if (serial == INVALID_HANDLE_VALUE) {
        printf("Failed to open port.\n");
        return;
    }

    printf("=== Live Log Feed (Press any key to exit) ===\n");
    char line[128];
    while (!_kbhit()) {
        if (readLineFromSerial(serial, line, sizeof(line)) > 0) {
            printf("%s\n", line);
            addLogFromSerial(line);
        }
        Sleep(10);
    }
    _getch();
    CloseHandle(serial);
}

void rebootArduino(const char* portName) {
    HANDLE hSerial = CreateFileA(portName, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);
    if (hSerial == INVALID_HANDLE_VALUE) {
        printf("Failed to open port for reboot.\n");
        return;
    }

    DCB dcb = {0};
    dcb.DCBlength = sizeof(dcb);
    GetCommState(hSerial, &dcb);
    dcb.BaudRate = 1200;
    SetCommState(hSerial, &dcb);
    CloseHandle(hSerial);
    printf("Reboot signal sent.\n");
    Sleep(2000);
}

void showWelcome() {
    system("cls");
    printf("========================================\n");
    printf(" W A T C H D O G X \n");
    printf("========================================\n");
    printf(" Secure Intrusion Logger & Monitor \n");
    printf("========================================\n\n");
}
