#include <stdio.h>
#include <string.h>
#include <windows.h>
#include <conio.h>
#include "WatchDogX.h"

#define ADMIN_CREDENTIALS_FILE "admin_credentials.txt"
#define USER_CREDENTIALS_FILE "user_credentials.txt"

int isAdmin = 0;
char currentUser[50];

void clearStdin() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

void getMaskedInput(char* buffer, int maxLen) {
    char ch;
    int i = 0;
    while ((ch = _getch()) != '\r' && i < maxLen - 1) {
        if (ch == '\b' && i > 0) {
            i--;
            printf("\b \b");
        } else if (ch != '\b') {
            buffer[i++] = ch;
            printf("*");
        }
    }
    buffer[i] = '\0';
    printf("\n");
}

void setCredentials(const char* filePath) {
    showWelcome();
    FILE* file = fopen(filePath, "wb");
    char username[50], password[50];
    printf("Set username: ");
    fgets(username, sizeof(username), stdin);
    username[strcspn(username, "\n")] = '\0';
    printf("Set password: ");
    getMaskedInput(password, sizeof(password));

    xorEncryptDecrypt((unsigned char*)username, strlen(username));
    xorEncryptDecrypt((unsigned char*)password, strlen(password));
    fprintf(file, "%s\n%s", username, password);
    fclose(file);
    printf("Credentials saved.\n");
    Sleep(1000);
}

int verifyCredentials(const char* filePath) {
    FILE* file = fopen(filePath, "rb");
    if (!file) {
        setCredentials(filePath);
        return verifyCredentials(filePath);
    }

    char storedUser[50], storedPass[50];
    fgets(storedUser, sizeof(storedUser), file);
    fgets(storedPass, sizeof(storedPass), file);
    fclose(file);

    storedUser[strcspn(storedUser, "\n")] = '\0';
    storedPass[strcspn(storedPass, "\n")] = '\0';
    xorEncryptDecrypt((unsigned char*)storedUser, strlen(storedUser));
    xorEncryptDecrypt((unsigned char*)storedPass, strlen(storedPass));

    char inputUser[50], inputPass[50];
    printf("Enter username: ");
    fgets(inputUser, sizeof(inputUser), stdin);
    inputUser[strcspn(inputUser, "\n")] = '\0';
    printf("Enter password: ");
    getMaskedInput(inputPass, sizeof(inputPass));

    if (strcmp(inputUser, storedUser) == 0 && strcmp(inputPass, storedPass) == 0) {
        strcpy(currentUser, inputUser);
        return 1;
    }
    return 0;
}

void loginMenu() {
    showWelcome();
    int role;
    printf("Choose Role:\n1. Admin\n2. User\nEnter choice: ");
    scanf("%d", &role);
    clearStdin();

    if (role == 1) {
        if (verifyCredentials(ADMIN_CREDENTIALS_FILE)) isAdmin = 1;
        else exit(1);
    } else if (role == 2) {
        if (verifyCredentials(USER_CREDENTIALS_FILE)) isAdmin = 0;
        else exit(1);
    } else {
        printf("Invalid selection.\n");
        exit(1);
    }
}

void showMenu() {
    int choice;
    do {
        showWelcome();
        printf("Logged in as: %s (%s)\n", currentUser, isAdmin ? "Admin" : "User");
        printf("1. View Logs\n");
        if (isAdmin) {
            printf("2. Add New Log\n3. Save Logs\n4. Load Logs\n5. Clear Memory\n6. Change Admin Credentials\n");
            printf("7. Change User Credentials\n8. Exit\n9. Live Log Feed\n10. Reboot Arduino\n");
        } else {
            printf("2. Load Logs\n3. Exit\n");
        }

        printf("Choice: ");
        scanf("%d", &choice);
        clearStdin();

        if (isAdmin) {
            switch (choice) {
                case 1: displayLogs(); break;
                case 2: addLog(); break;
                case 3: saveLogsToFile(); break;
                case 4: loadLogsFromFile(); break;
                case 5: clearLogs(); break;
                case 6: setCredentials(ADMIN_CREDENTIALS_FILE); break;
                case 7: setCredentials(USER_CREDENTIALS_FILE); break;
                case 8: printf("Exiting...\n"); break;
                case 9: liveLogFeedFromArduino(); break;
                case 10: rebootArduino("\\\\.\\COM3"); break;
                default: printf("Invalid input!\n"); Sleep(1000);
            }
        } else {
            switch (choice) {
                case 1: displayLogs(); break;
                case 2: loadLogsFromFile(); break;
                case 3: printf("Exiting...\n"); break;
                default: printf("Invalid input!\n"); Sleep(1000);
            }
        }
    } while ((isAdmin && choice != 8) || (!isAdmin && choice != 3));
}

int main() {
    showWelcome();
    loginMenu();
    loadLogsFromFile();
    showMenu();
    saveLogsToFile();
    clearLogs();
    return 0;
}
